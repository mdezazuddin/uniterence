$(function(){ 
    // Initialize Swiper      
    var swiper1 = new Swiper('.swiper1', {
      slidesPerView: 1, 
      autoplay:true,
      loop: true,
      speed: 200,      
      pagination: {
          el: '.swiper-pagination',
          clickable: true,
      },

      navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev',
      }    
    }); 


    // Initialize Swiper      
    var swiper2 = new Swiper('.swiper2', {
      slidesPerView: 1, 
      autoplay:true,
      loop: true,
      speed: 200,      
      pagination: {
          el: '.swiper-pagination',
          clickable: true,
      },

      navigation: {
          nextEl: '.fa-angle-right',
          prevEl: '.fa-angle-left',
      }
    }); 



    // Initialize Swiper      
    var swiper6 = new Swiper('.swiper6', {
      slidesPerView: 1,    
      spaceBetween: 10,
      autoplay:true,
      loop: true,
      speed: 200,      
      pagination: {
          el: '.swiper-pagination',
          clickable: true,
      },

      navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev',
      },

      // Responsive breakpoints
      breakpoints: {
          // when window width is <= 480px
          480: {
          slidesPerView: 1,
          spaceBetween: 10
          },
          // when window width is <= 640px
          768: {
          slidesPerView: 2,
          spaceBetween: 10
          },
          // when window width is <= 640px
          992: {
          slidesPerView: 3,
          spaceBetween: 10
          }
      },    
    }); 


    // Initialize Swiper      
    var swiper5 = new Swiper('.swiper5', {
      slidesPerView: 1,  
      autoplay:true,
      direction: "vertical",
      loop: true,
      speed: 200,      
      pagination: {
          el: '.swiper-pagination',
          clickable: true,
      },

      navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev',
      }  
    }); 
 });